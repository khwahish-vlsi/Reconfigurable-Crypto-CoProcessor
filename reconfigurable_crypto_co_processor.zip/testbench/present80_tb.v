`timescale 1ns/1ps
module present80_tb;
    reg [63:0] plaintext;
    reg [79:0] key;
    wire [63:0] ciphertext;

    present80_encrypt dut(.plaintext(plaintext), .key(key), .ciphertext(ciphertext));

    initial begin
        plaintext = 64'h0000000000000000;
        key       = 80'h00000000000000000000;
        #1;
        $display("PRESENT-80 ciphertext = %016h", ciphertext);
        if (ciphertext !== 64'h5579C1387B228445) begin
            $display("PRESENT-80 TEST: FAIL");
            $fatal;
        end
        $display("PRESENT-80 TEST: PASS");
        $finish;
    end
endmodule
