`timescale 1ns/1ps
module aes128_tb;
    reg [127:0] plaintext;
    reg [127:0] key;
    wire [127:0] ciphertext;

    aes128_encrypt dut(.plaintext(plaintext), .key(key), .ciphertext(ciphertext));

    initial begin
        plaintext = 128'h00112233445566778899AABBCCDDEEFF;
        key       = 128'h000102030405060708090A0B0C0D0E0F;
        #1;
        $display("AES-128 ciphertext = %032h", ciphertext);
        if (ciphertext !== 128'h69C4E0D86A7B0430D8CDB78070B4C55A) begin
            $display("AES-128 TEST: FAIL");
            $fatal;
        end
        $display("AES-128 TEST: PASS");
        $finish;
    end
endmodule
