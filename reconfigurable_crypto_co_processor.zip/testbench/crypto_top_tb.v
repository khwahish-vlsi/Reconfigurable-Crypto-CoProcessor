`timescale 1ns/1ps
module crypto_top_tb;
    reg mode;
    reg [127:0] plaintext, key;
    wire [127:0] ciphertext;
    crypto_top dut(.mode(mode), .plaintext(plaintext), .key(key), .ciphertext(ciphertext));

    initial begin
        mode=1'b0;
        plaintext=128'h00112233445566778899AABBCCDDEEFF;
        key=128'h000102030405060708090A0B0C0D0E0F;
        #1;
        if (ciphertext !== 128'h69C4E0D86A7B0430D8CDB78070B4C55A)
            $fatal(1, "Top AES mode failed: %032h", ciphertext);
        $display("Top AES mode PASS");

        mode=1'b1;
        plaintext=128'h00000000000000000000000000000000;
        key=128'h00000000000000000000000000000000;
        #1;
        if (ciphertext[63:0] !== 64'h5579C1387B228445 || ciphertext[127:64] !== 64'b0)
            $fatal(1, "Top PRESENT mode failed: %032h", ciphertext);
        $display("Top PRESENT mode PASS");
        $finish;
    end
endmodule
