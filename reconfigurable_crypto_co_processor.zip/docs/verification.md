# Verification

Run the self-checking testbenches from the repository root using the commands in README.md. Save actual simulator output only after running the tests. Do not commit fabricated logs or screenshots.
