// PRESENT-80 encryption core
// Standard PRESENT-80: 64-bit block, 80-bit key, 31 rounds.
// Combinational implementation intended for simulation/learning.
module present80_encrypt (
    input  wire [63:0] plaintext,
    input  wire [79:0] key,
    output reg  [63:0] ciphertext
);
    integer r, i;
    reg [63:0] state;
    reg [79:0] k;
    reg [63:0] sb;
    reg [3:0] nib;
    reg [4:0] rc;

    function [3:0] present_sbox;
        input [3:0] x;
        begin
            case (x)
                4'h0: present_sbox=4'hC; 4'h1: present_sbox=4'h5;
                4'h2: present_sbox=4'h6; 4'h3: present_sbox=4'hB;
                4'h4: present_sbox=4'h9; 4'h5: present_sbox=4'h0;
                4'h6: present_sbox=4'hA; 4'h7: present_sbox=4'hD;
                4'h8: present_sbox=4'h3; 4'h9: present_sbox=4'hE;
                4'hA: present_sbox=4'hF; 4'hB: present_sbox=4'h8;
                4'hC: present_sbox=4'h4; 4'hD: present_sbox=4'h7;
                4'hE: present_sbox=4'h1; 4'hF: present_sbox=4'h2;
            endcase
        end
    endfunction

    function [63:0] present_pbox;
        input [63:0] x;
        integer j, dst;
        begin
            present_pbox = 64'b0;
            for (j=0; j<63; j=j+1) begin
                dst = (16*j) % 63;
                present_pbox[dst] = x[j];
            end
            present_pbox[63] = x[63];
        end
    endfunction

    always @* begin
        state = plaintext;
        k = key;
        sb = 64'b0;
        nib = 4'b0;
        rc = 5'b0;

        for (r=1; r<=31; r=r+1) begin
            state = state ^ k[79:16];
            for (i=0; i<16; i=i+1) begin
                nib = state[4*i +: 4];
                sb[4*i +: 4] = present_sbox(nib);
            end
            state = present_pbox(sb);

            // PRESENT-80 key schedule: rotate left 61, S-box top nibble,
            // then XOR round counter into key bits [19:15].
            k = {k[18:0], k[79:19]};
            k[79:76] = present_sbox(k[79:76]);
            rc = r[4:0];
            k[19:15] = k[19:15] ^ rc;
        end
        ciphertext = state ^ k[79:16];
    end
endmodule
