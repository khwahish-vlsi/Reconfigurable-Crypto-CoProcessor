// Top-level selector for AES-128 and PRESENT-80 encryption.
// mode=0: AES-128 uses all 128 key/plaintext bits.
// mode=1: PRESENT-80 uses plaintext[63:0] and key[79:0]; result is zero-extended.
module crypto_top (
    input  wire         mode,
    input  wire [127:0] plaintext,
    input  wire [127:0] key,
    output wire [127:0] ciphertext
);
    wire [127:0] aes_ct;
    wire [63:0]  present_ct;

    aes128_encrypt u_aes (
        .plaintext(plaintext),
        .key(key),
        .ciphertext(aes_ct)
    );

    present80_encrypt u_present (
        .plaintext(plaintext[63:0]),
        .key(key[79:0]),
        .ciphertext(present_ct)
    );

    assign ciphertext = mode ? {64'b0, present_ct} : aes_ct;
endmodule
