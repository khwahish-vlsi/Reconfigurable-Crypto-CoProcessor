# Reconfigurable Cryptographic Co-Processor (AES-128 + PRESENT-80)

This repository contains a reconstructed Verilog reference implementation of two encryption cores and a mode-selection top module:
- AES-128 encryption (128-bit plaintext and key)
- PRESENT-80 encryption (64-bit plaintext and 80-bit key)
- `crypto_top` mode selector (`mode=0` for AES-128, `mode=1` for PRESENT-80)
- Self-checking testbenches using standard known-answer test vectors

**Important:** This is a reconstructed implementation, not a claim that these files are the user's original source. Verify it in your simulator and compare it against the project specification before submission.

## Layout
```text
rtl/
  aes/aes128_encrypt.v
  present/present80_encrypt.v
  crypto_top.v
testbench/
  aes128_tb.v
  present80_tb.v
  crypto_top_tb.v
```

## Known-answer tests
- PRESENT-80: zero plaintext, zero 80-bit key → `5579C1387B228445`
- AES-128: plaintext `00112233445566778899AABBCCDDEEFF`, key `000102030405060708090A0B0C0D0E0F` → `69C4E0D86A7B0430D8CDB78070B4C55A`

## Simulate with Icarus Verilog
From the repository root:
```sh
iverilog -g2012 -o present_test rtl/present/present80_encrypt.v testbench/present80_tb.v
vvp present_test

iverilog -g2012 -o aes_test rtl/aes/aes128_encrypt.v testbench/aes128_tb.v
vvp aes_test

iverilog -g2012 -o top_test rtl/aes/aes128_encrypt.v rtl/present/present80_encrypt.v rtl/crypto_top.v testbench/crypto_top_tb.v
vvp top_test
```

The testbenches are intended to fail if the output does not match the known-answer vector. Do not describe tests as passing until you have run them and confirmed the output.

## Design note
The encryption cores here are combinational reference implementations for clarity and functional testing. They are not pipelined/iterative high-throughput architectures and have not been timing-closed or validated for a specific FPGA/ASIC flow. Synthesis quality, area, and timing depend on the tool and target technology.
