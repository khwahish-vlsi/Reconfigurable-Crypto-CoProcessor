# RISC-V firmware generator #4: fixed regression on the SHARED core:
# AES, PRESENT (key 0), PRESENT (key all ones), AES again -> prints 600D600D / BAD0C0DE per test.
P = []
L = {}
n = [0]
def emit(x): P.append(x)
def label(s): L[s] = len(P)
def I(op, f3, rd, rs1, imm):
    emit(((imm & 0xFFF) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op)
def addi(rd, rs, imm): I(0x13, 0, rd, rs, imm)
def andi(rd, rs, imm): I(0x13, 7, rd, rs, imm)
def lw(rd, off, rs1):  I(0x03, 2, rd, rs1, off)
def sw(rs2, off, rs1):
    imm = off & 0xFFF
    emit(((imm >> 5) << 25) | (rs2 << 20) | (rs1 << 15) | (2 << 12) | ((imm & 31) << 7) | 0x23)
def rt(f7, f3, rd, a, b):
    emit((f7 << 25) | (b << 20) | (a << 15) | (f3 << 12) | (rd << 7) | 0x33)
def add(rd, a, b):  rt(0x00, 0, rd, a, b)
def sub(rd, a, b):  rt(0x20, 0, rd, a, b)
def xor_(rd, a, b): rt(0x00, 4, rd, a, b)
def or_(rd, a, b):  rt(0x00, 6, rd, a, b)
def bne(a, b, lab): emit(('b', 1, a, b, lab))
def jal(rd, lab):   emit(('j', rd, lab))
def li(rd, v):
    v &= 0xFFFFFFFF
    s = v - (1 << 32) if v >= 0x80000000 else v
    if -2048 <= s < 2048:
        addi(rd, 0, s)
        return
    hi = ((v + 0x800) >> 12) & 0xFFFFF
    lo = ((v & 0xFFF) ^ 0x800) - 0x800
    emit((hi << 12) | (rd << 7) | 0x37)
    if lo:
        addi(rd, rd, lo)

KEY, PT, CT = 4, 8, 12

def test(tid, slot, mode, key, pt, exp, first):
    n[0] += 1
    t = n[0]
    li(10, 0x40000000 + slot * 0x1000)
    li(11, 0x50000000)
    li(12, 0xA0000000 + tid); sw(12, 0, 11)
    li(12, mode); sw(12, 0x14, 11)
    for i in range(4):
        li(12, key[i]); sw(12, (KEY + i) * 4, 10); sw(12, 0x08, 11)
    for i in range(4):
        li(12, pt[i]); sw(12, (PT + i) * 4, 10); sw(12, 0x0C, 11)
    li(12, 1 | (mode << 1)); sw(12, 0, 10)
    li(15, 100000)
    label('poll%d' % t)
    lw(13, 4, 10); andi(13, 13, 2)
    bne(13, 0, 'done%d' % t)
    addi(15, 15, -1)
    bne(15, 0, 'poll%d' % t)
    li(12, 0xBAD0BAD0); sw(12, 0, 11)
    jal(0, 'end%d' % t)
    label('done%d' % t)
    li(14, 0)
    for i, e in enumerate(exp):
        lw(13, (CT + first + i) * 4, 10); sw(13, 0x10, 11)
        li(12, e); xor_(12, 13, 12); or_(14, 14, 12)
    bne(14, 0, 'fail%d' % t)
    li(12, 0x600D600D)
    jal(0, 'out%d' % t)
    label('fail%d' % t)
    li(12, 0xBAD0C0DE)
    label('out%d' % t)
    sw(12, 0, 11)
    label('end%d' % t)

ak  = [0x2b7e1516, 0x28aed2a6, 0xabf71588, 0x09cf4f3c]
ap  = [0x3243f6a8, 0x885a308d, 0x313198a2, 0xe0370734]
ae  = [0x3925841d, 0x02dc09fb, 0xdc118597, 0x196a0b32]
pk0 = [0, 0, 0, 0]
pk1 = [0, 0x0000ffff, 0xffffffff, 0xffffffff]
pp0 = [0, 0, 0, 0]
pe0 = [0x5579c138, 0x7b228445]
pe1 = [0xe72c46c0, 0xf5945049]

test(1, 1, 0, ak,  ap,  ae,  0)   # AES
test(2, 1, 1, pk0, pp0, pe0, 2)   # PRESENT, key = 0
test(3, 1, 1, pk1, pp0, pe1, 2)   # PRESENT, key = all ones
test(4, 1, 0, ak,  ap,  ae,  0)   # AES again (shows mode switching)

li(11, 0x50000000); li(12, 1); sw(12, 4, 11)
label('hang'); jal(0, 'hang')

out = []
for idx, x in enumerate(P):
    if isinstance(x, tuple):
        if x[0] == 'b':
            _, f3, rs1, rs2, lab = x
            o = ((L[lab] - idx) * 4) & 0x1FFF
            x = (((o >> 12) & 1) << 31) | (((o >> 5) & 0x3F) << 25) | (rs2 << 20) | \
                (rs1 << 15) | (f3 << 12) | (((o >> 1) & 0xF) << 8) | (((o >> 11) & 1) << 7) | 0x63
        else:
            _, rd, lab = x
            o = ((L[lab] - idx) * 4) & 0x1FFFFF
            x = (((o >> 20) & 1) << 31) | (((o >> 1) & 0x3FF) << 21) | \
                (((o >> 11) & 1) << 20) | (((o >> 12) & 0xFF) << 12) | (rd << 7) | 0x6F
    out.append('%08x' % x)
open('firmware.hex', 'w').write('\n'.join(out) + '\n')
print('wrote firmware.hex with %d words' % len(out))
