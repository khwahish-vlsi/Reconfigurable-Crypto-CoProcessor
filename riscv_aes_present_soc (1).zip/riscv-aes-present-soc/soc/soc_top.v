module soc_top (
    input clk, input resetn,
    input mode_in, input [127:0] key_in, input [127:0] pt_in
);
    wire        mem_valid, mem_instr;
    wire [31:0] mem_addr, mem_wdata;
    wire [3:0]  mem_wstrb;
    reg         mem_ready = 0;
    reg  [31:0] mem_rdata = 0;

    picorv32 #(.PROGADDR_RESET(32'h0), .STACKADDR(32'h0001_0000)) cpu (
        .clk(clk), .resetn(resetn), .trap(),
        .mem_valid(mem_valid), .mem_instr(mem_instr), .mem_ready(mem_ready),
        .mem_addr(mem_addr), .mem_wdata(mem_wdata),
        .mem_wstrb(mem_wstrb), .mem_rdata(mem_rdata));

    wire xfer    = mem_valid && !mem_ready;
    wire is_wr   = xfer && (|mem_wstrb);
    wire sel_ram = (mem_addr[31:16] == 16'h0000);
    wire sel_cry = (mem_addr[31:16] == 16'h4000);
    wire sel_sim = (mem_addr[31:16] == 16'h5000);
    wire [3:0] slot = mem_addr[15:12];
    wire [4:0] widx = mem_addr[6:2];

    reg [31:0] ram [0:16383];
    initial $readmemh("firmware.hex", ram);

    reg [31:0] cyc = 0;
    always @(posedge clk) cyc <= resetn ? cyc + 1 : 32'd0;

    // ---------- shared crypto core (slot 1) ----------
    wire [31:0] rd1; wire m1, s1, d1, b1; wire [127:0] k1, p1, c1;
    crypto_mmio mm1 (.clk(clk), .resetn(resetn), .wr(is_wr && sel_cry && slot==1),
        .widx(widx), .wdata(mem_wdata), .rdata(rd1), .mode(m1), .start(s1),
        .key(k1), .pt(p1), .ct(c1), .core_done(d1), .core_busy(b1));
    crypto_top u_shared (.clk(clk), .reset_n(resetn), .mode(m1), .start(s1),
        .plaintext(p1), .key(k1), .ciphertext(c1), .done(d1), .busy(b1));

    always @(posedge clk) begin
        mem_ready <= 1'b0;
        if (resetn && xfer) begin
            mem_ready <= 1'b1;
            if (sel_ram) begin
                mem_rdata <= ram[mem_addr[15:2]];
                if (mem_wstrb[0]) ram[mem_addr[15:2]][ 7: 0] <= mem_wdata[ 7: 0];
                if (mem_wstrb[1]) ram[mem_addr[15:2]][15: 8] <= mem_wdata[15: 8];
                if (mem_wstrb[2]) ram[mem_addr[15:2]][23:16] <= mem_wdata[23:16];
                if (mem_wstrb[3]) ram[mem_addr[15:2]][31:24] <= mem_wdata[31:24];
            end else if (sel_cry)
                mem_rdata <= (slot==1) ? rd1 : 32'h0;
            else if (sel_sim) begin
                case (mem_addr[8:2])
                    7'h40: mem_rdata <= {31'b0, mode_in};
                    7'h44: mem_rdata <= key_in[127:96];
                    7'h45: mem_rdata <= key_in[95:64];
                    7'h46: mem_rdata <= key_in[63:32];
                    7'h47: mem_rdata <= key_in[31:0];
                    7'h48: mem_rdata <= pt_in[127:96];
                    7'h49: mem_rdata <= pt_in[95:64];
                    7'h4A: mem_rdata <= pt_in[63:32];
                    7'h4B: mem_rdata <= pt_in[31:0];
                    7'h4C: mem_rdata <= cyc;
                    default: mem_rdata <= 32'h0;
                endcase
            end else
                mem_rdata <= 32'h0;
        end
    end

    // ---------- RISC-V activity monitor (simulation only) ----------
    integer n_cyc = 0, n_instr = 0, n_ramrd = 0, n_ramwr = 0;
    integer n_cwr = 0, n_crd = 0, n_poll = 0, n_busy = 0;
    reg trace;
    initial trace = $test$plusargs("TRACE");
    wire bus_done = mem_valid && mem_ready;
    always @(posedge clk) if (resetn) begin
        n_cyc <= n_cyc + 1;
        if (b1) n_busy <= n_busy + 1;
        if (bus_done) begin
            if (mem_instr) begin
                n_instr <= n_instr + 1;
                if (trace) $display("[PC ] %08h   instr %08h", mem_addr, mem_rdata);
            end else if (sel_ram) begin
                if (|mem_wstrb) n_ramwr <= n_ramwr + 1; else n_ramrd <= n_ramrd + 1;
            end else if (sel_cry) begin
                if (|mem_wstrb) begin
                    n_cwr <= n_cwr + 1;
                    $display("[BUS] t=%0t  RISC-V WRITE  0x%08h <= %08h", $time, mem_addr, mem_wdata);
                end else begin
                    n_crd <= n_crd + 1;
                    if (mem_addr[6:2] == 5'd1) n_poll <= n_poll + 1;
                    else $display("[BUS] t=%0t  RISC-V READ   0x%08h => %08h", $time, mem_addr, mem_rdata);
                end
            end
        end
    end

    // ---------- simulation console ----------
    always @(posedge clk)
        if (is_wr && sel_sim)
            case (mem_addr[5:2])
                4'd0: $display("[FW] marker %08h", mem_wdata);
                4'd1: begin
                    $display("");
                    $display("=========== RISC-V ACTIVITY REPORT ===========");
                    $display(" Total clock cycles               : %0d", n_cyc);
                    $display(" Instructions executed by CPU     : %0d", n_instr);
                    $display(" Average clocks per instruction   : %0f", 1.0 * n_cyc / n_instr);
                    $display(" RAM data reads / writes          : %0d / %0d", n_ramrd, n_ramwr);
                    $display(" Writes to crypto core registers  : %0d", n_cwr);
                    $display(" Reads from crypto core registers : %0d (status polls: %0d)", n_crd, n_poll);
                    $display(" Cycles the crypto core was busy  : %0d", n_busy);
                    $display("==============================================");
                    $finish;
                end
                4'd2: $display("          KEY    : %08h", mem_wdata);
                4'd3: $display("          PT     : %08h", mem_wdata);
                4'd4: $display("          CT     : %08h", mem_wdata);
                4'd5: $display("          MODE   : %0d  (0=AES, 1=PRESENT)", mem_wdata);
                4'd6: $display("          CYCLES : %0d", mem_wdata);
                4'd7: $display("          ENC    : %08h", mem_wdata);
                4'd8: $display("          DEC    : %08h", mem_wdata);
                4'd9: $display("          SELF-CHECK: %s", (mem_wdata == 1) ? "PASS" : "FAIL");
                4'd10: case (mem_wdata)
                    1: $display("[RISC-V] t=%0t  STEP 1: booted, running the program from RAM", $time);
                    2: $display("[RISC-V] t=%0t  STEP 2: read the algorithm choice (mode) from the user input", $time);
                    3: $display("[RISC-V] t=%0t  STEP 3: writing the KEY into the shared crypto core", $time);
                    4: $display("[RISC-V] t=%0t  STEP 4: writing the PLAINTEXT into the shared crypto core", $time);
                    5: $display("[RISC-V] t=%0t  STEP 5: writing CTRL = start + mode", $time);
                    6: $display("[RISC-V] t=%0t  STEP 6: polling STATUS, waiting for done", $time);
                    7: $display("[RISC-V] t=%0t  STEP 7: STATUS shows DONE", $time);
                    8: $display("[RISC-V] t=%0t  STEP 8: reading the CIPHERTEXT back", $time);
                    9: $display("[RISC-V] t=%0t  STEP 9: all results read, ending", $time);
                endcase
            endcase
endmodule
