# RISC-V firmware generator #2: one operation + cycle count, then a 32-byte message
# encrypted in counter mode by the CPU, decrypted again and self-checked.
import struct
P = []
L = {}
n = [0]
def emit(x): P.append(x)
def label(s): L[s] = len(P)
def I(op, f3, rd, rs1, imm):
    emit(((imm & 0xFFF) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op)
def addi(rd, rs, imm): I(0x13, 0, rd, rs, imm)
def andi(rd, rs, imm): I(0x13, 7, rd, rs, imm)
def lw(rd, off, rs1):  I(0x03, 2, rd, rs1, off)
def sw(rs2, off, rs1):
    imm = off & 0xFFF
    emit(((imm >> 5) << 25) | (rs2 << 20) | (rs1 << 15) | (2 << 12) | ((imm & 31) << 7) | 0x23)
def rt(f7, f3, rd, a, b):
    emit((f7 << 25) | (b << 20) | (a << 15) | (f3 << 12) | (rd << 7) | 0x33)
def add(rd, a, b):  rt(0x00, 0, rd, a, b)
def sub(rd, a, b):  rt(0x20, 0, rd, a, b)
def xor_(rd, a, b): rt(0x00, 4, rd, a, b)
def or_(rd, a, b):  rt(0x00, 6, rd, a, b)
def bne(a, b, lab): emit(('b', 1, a, b, lab))
def jal(rd, lab):   emit(('j', rd, lab))
def li(rd, v):
    v &= 0xFFFFFFFF
    s = v - (1 << 32) if v >= 0x80000000 else v
    if -2048 <= s < 2048:
        addi(rd, 0, s)
        return
    hi = ((v + 0x800) >> 12) & 0xFFFFF
    lo = ((v & 0xFFF) ^ 0x800) - 0x800
    emit((hi << 12) | (rd << 7) | 0x37)
    if lo:
        addi(rd, rd, lo)

KEY, PT, CT = 4, 8, 12
# x5=mode  x6=RAM buffer  x7=error flags  x10=crypto base  x11=console base

def start():
    add(12, 5, 5); addi(12, 12, 1); sw(12, 0, 10)

def poll():
    n[0] += 1
    t = n[0]
    li(15, 100000)
    label('poll%d' % t)
    lw(13, 4, 10); andi(13, 13, 2)
    bne(13, 0, 'ok%d' % t)
    addi(15, 15, -1)
    bne(15, 0, 'poll%d' % t)
    li(12, 0xBAD0BAD0); sw(12, 0, 11)
    jal(0, 'fin')
    label('ok%d' % t)

def block(c):                      # encrypt counter block c, keystream -> x13,x14
    for i in range(3):
        sw(0, (PT + i) * 4, 10)
    li(12, c); sw(12, (PT + 3) * 4, 10)
    start(); poll()
    lw(13, (CT + 2) * 4, 10)
    lw(14, (CT + 3) * 4, 10)

msg = b"PicoRV32 controls AES and PRESENT"[:32].ljust(32)
W = struct.unpack('<8I', msg)

li(10, 0x40001000)
li(11, 0x50000000)
li(6, 0x6000)
li(7, 0)

# ---------- Part A: one operation with user mode, key, plaintext + cycle count ----------
li(12, 0xA0000001); sw(12, 0, 11)
lw(5, 0x100, 11); sw(5, 0x14, 11)
for i in range(4):
    lw(12, 0x110 + 4 * i, 11); sw(12, (KEY + i) * 4, 10); sw(12, 0x08, 11)
for i in range(4):
    lw(12, 0x120 + 4 * i, 11); sw(12, (PT + i) * 4, 10); sw(12, 0x0C, 11)
lw(16, 0x130, 11)
start(); poll()
lw(17, 0x130, 11); sub(17, 17, 16); sw(17, 0x18, 11)
for i in range(4):
    lw(13, (CT + i) * 4, 10); sw(13, 0x10, 11)

# ---------- Part B: encrypt a 32-byte message in counter mode ----------
li(12, 0xA0000002); sw(12, 0, 11)
for b in range(4):
    block(b + 1)
    li(12, W[2 * b]);     xor_(13, 13, 12)
    li(12, W[2 * b + 1]); xor_(14, 14, 12)
    sw(13, 8 * b, 6); sw(14, 8 * b + 4, 6)
    sw(13, 0x1C, 11); sw(14, 0x1C, 11)

# ---------- Part C: decrypt and self-check ----------
li(12, 0xA0000003); sw(12, 0, 11)
for b in range(4):
    block(b + 1)
    lw(12, 8 * b, 6);     xor_(13, 13, 12)
    lw(12, 8 * b + 4, 6); xor_(14, 14, 12)
    sw(13, 0x20, 11); sw(14, 0x20, 11)
    li(12, W[2 * b]);     xor_(12, 13, 12); or_(7, 7, 12)
    li(12, W[2 * b + 1]); xor_(12, 14, 12); or_(7, 7, 12)
bne(7, 0, 'bad')
li(12, 1); sw(12, 0x24, 11)
jal(0, 'fin')
label('bad')
li(12, 0); sw(12, 0x24, 11)
label('fin')
li(12, 1); sw(12, 4, 11)
label('hang'); jal(0, 'hang')

out = []
for idx, x in enumerate(P):
    if isinstance(x, tuple):
        if x[0] == 'b':
            _, f3, rs1, rs2, lab = x
            o = ((L[lab] - idx) * 4) & 0x1FFF
            x = (((o >> 12) & 1) << 31) | (((o >> 5) & 0x3F) << 25) | (rs2 << 20) | \
                (rs1 << 15) | (f3 << 12) | (((o >> 1) & 0xF) << 8) | (((o >> 11) & 1) << 7) | 0x63
        else:
            _, rd, lab = x
            o = ((L[lab] - idx) * 4) & 0x1FFFFF
            x = (((o >> 20) & 1) << 31) | (((o >> 1) & 0x3FF) << 21) | \
                (((o >> 11) & 1) << 20) | (((o >> 12) & 0xFF) << 12) | (rd << 7) | 0x6F
    out.append('%08x' % x)
open('firmware.hex', 'w').write('\n'.join(out) + '\n')
print('wrote firmware.hex with %d words' % len(out))
