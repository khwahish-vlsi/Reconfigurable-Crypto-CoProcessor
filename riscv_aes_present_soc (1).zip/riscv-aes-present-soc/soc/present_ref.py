# Software PRESENT-80 reference model. Usage: python3 present_ref.py <key 20 hex> <plaintext 16 hex>
import sys
S = [0xC,5,6,0xB,9,0,0xA,0xD,3,0xE,0xF,8,4,7,1,2]
def present80(key, pt):
    k, s = key, pt
    for r in range(1, 32):
        s ^= k >> 16
        t = 0
        for i in range(16):
            t |= S[(s >> (4*i)) & 0xF] << (4*i)
        p = 0
        for i in range(64):
            j = 63 if i == 63 else (16*i) % 63
            p |= ((t >> i) & 1) << j
        s = p
        k = ((k << 61) | (k >> 19)) & ((1 << 80) - 1)
        k = (S[k >> 76] << 76) | (k & ((1 << 76) - 1))
        k ^= r << 15
    return s ^ (k >> 16)
if __name__ == "__main__":
    key = int(sys.argv[1], 16)
    pt = int(sys.argv[2], 16)
    print("KEY      : %020x" % key)
    print("PLAINTEXT: %016x" % pt)
    print("EXPECTED : %016x" % present80(key, pt))
