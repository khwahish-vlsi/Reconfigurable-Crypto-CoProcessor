`timescale 1ns/1ps
// Simple user-input testbench: +MODE=0 -> AES-128, +MODE=1 -> PRESENT-80 (built-in vectors)
module tb;
    reg clk = 0, resetn = 0;
    reg         mode_in;
    reg [127:0] key_in, pt_in, exp_in, act;
    reg         started, shown;
    integer     MODE;

    always #5 clk = ~clk;

    soc_top dut (.clk(clk), .resetn(resetn),
                 .mode_in(mode_in), .key_in(key_in), .pt_in(pt_in));

    initial begin
        started = 0; shown = 0;
        if (!$value$plusargs("MODE=%d", MODE)) MODE = 0;
        if (MODE == 0) begin
            mode_in = 1'b0;
            key_in  = 128'h2b7e151628aed2a6abf7158809cf4f3c;
            pt_in   = 128'h3243f6a8885a308d313198a2e0370734;
            exp_in  = 128'h3925841d02dc09fbdc118597196a0b32;
            $display("SELECTED MODE : 0 (AES-128)");
        end else begin
            mode_in = 1'b1;
            key_in  = 128'hA1B2C3D4E5F6A7B8C9D0;
            pt_in   = 128'hFEDCBA9876543210;
            exp_in  = 128'hA8DC5293C96325F3;   // from present_ref.py
            $display("SELECTED MODE : 1 (PRESENT-80)");
        end
        repeat (20) @(posedge clk);
        resetn = 1'b1;
    end

    always @(posedge dut.s1) started = 1'b1;

    always @(posedge dut.u_shared.done)
        if (resetn && started && !shown) begin
            shown = 1'b1;
            @(posedge clk);
            act = dut.u_shared.ciphertext;
            $display("[SIMULATION RESULT START]");
            if (MODE == 0) begin
                $display("MODE        : 0 (AES-128)");
                $display("KEY         : %032h", key_in);
                $display("PLAINTEXT   : %032h", pt_in);
                $display("EXPECTED CT : %032h", exp_in);
                $display("ACTUAL CT   : %032h", act);
                $display("STATUS      : %s", (act == exp_in) ? "PASS" : "FAIL");
            end else begin
                $display("MODE        : 1 (PRESENT-80)");
                $display("KEY         : %020h", key_in[79:0]);
                $display("PLAINTEXT   : %016h", pt_in[63:0]);
                $display("EXPECTED CT : %016h", exp_in[63:0]);
                $display("ACTUAL CT   : %016h", act[63:0]);
                $display("STATUS      : %s", (act[63:0] == exp_in[63:0]) ? "PASS" : "FAIL");
            end
            $display("[SIMULATION RESULT END]");
            $finish;
        end

    initial begin #50_000_000; $display("ERROR: SIMULATION TIMEOUT"); $finish; end
endmodule
