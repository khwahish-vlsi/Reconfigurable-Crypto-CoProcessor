# RISC-V firmware generator #1: read mode/key/plaintext from the user-input registers,
# run ONE encryption on the shared core (slot 1), print the ciphertext.
P = []
L = {}
n = [0]
def emit(x): P.append(x)
def label(s): L[s] = len(P)
def I(op, f3, rd, rs1, imm):
    emit(((imm & 0xFFF) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op)
def addi(rd, rs, imm): I(0x13, 0, rd, rs, imm)
def andi(rd, rs, imm): I(0x13, 7, rd, rs, imm)
def lw(rd, off, rs1):  I(0x03, 2, rd, rs1, off)
def sw(rs2, off, rs1):
    imm = off & 0xFFF
    emit(((imm >> 5) << 25) | (rs2 << 20) | (rs1 << 15) | (2 << 12) | ((imm & 31) << 7) | 0x23)
def rt(f7, f3, rd, a, b):
    emit((f7 << 25) | (b << 20) | (a << 15) | (f3 << 12) | (rd << 7) | 0x33)
def add(rd, a, b):  rt(0x00, 0, rd, a, b)
def sub(rd, a, b):  rt(0x20, 0, rd, a, b)
def xor_(rd, a, b): rt(0x00, 4, rd, a, b)
def or_(rd, a, b):  rt(0x00, 6, rd, a, b)
def bne(a, b, lab): emit(('b', 1, a, b, lab))
def jal(rd, lab):   emit(('j', rd, lab))
def li(rd, v):
    v &= 0xFFFFFFFF
    s = v - (1 << 32) if v >= 0x80000000 else v
    if -2048 <= s < 2048:
        addi(rd, 0, s)
        return
    hi = ((v + 0x800) >> 12) & 0xFFFFF
    lo = ((v & 0xFFF) ^ 0x800) - 0x800
    emit((hi << 12) | (rd << 7) | 0x37)
    if lo:
        addi(rd, rd, lo)

KEY, PT, CT = 4, 8, 12

li(10, 0x40001000)                   # shared crypto base
li(11, 0x50000000)                   # console / user-input base
li(12, 0xA0000001); sw(12, 0, 11)    # marker
lw(5, 0x100, 11)                     # mode chosen by the user
sw(5, 0x14, 11)                      # print mode
for i in range(4):
    lw(12, 0x110 + 4 * i, 11); sw(12, (KEY + i) * 4, 10); sw(12, 0x08, 11)
for i in range(4):
    lw(12, 0x120 + 4 * i, 11); sw(12, (PT + i) * 4, 10); sw(12, 0x0C, 11)
add(12, 5, 5); addi(12, 12, 1); sw(12, 0, 10)      # CTRL = start | mode<<1
li(15, 100000)
label('poll')
lw(13, 4, 10); andi(13, 13, 2)
bne(13, 0, 'done')
addi(15, 15, -1)
bne(15, 0, 'poll')
li(12, 0xBAD0BAD0); sw(12, 0, 11)
jal(0, 'fin')
label('done')
for i in range(4):
    lw(13, (CT + i) * 4, 10); sw(13, 0x10, 11)
label('fin')
li(12, 1); sw(12, 4, 11)
label('hang'); jal(0, 'hang')

out = []
for idx, x in enumerate(P):
    if isinstance(x, tuple):
        if x[0] == 'b':
            _, f3, rs1, rs2, lab = x
            o = ((L[lab] - idx) * 4) & 0x1FFF
            x = (((o >> 12) & 1) << 31) | (((o >> 5) & 0x3F) << 25) | (rs2 << 20) | \
                (rs1 << 15) | (f3 << 12) | (((o >> 1) & 0xF) << 8) | (((o >> 11) & 1) << 7) | 0x63
        else:
            _, rd, lab = x
            o = ((L[lab] - idx) * 4) & 0x1FFFFF
            x = (((o >> 20) & 1) << 31) | (((o >> 1) & 0x3FF) << 21) | \
                (((o >> 11) & 1) << 20) | (((o >> 12) & 0xFF) << 12) | (rd << 7) | 0x6F
    out.append('%08x' % x)
open('firmware.hex', 'w').write('\n'.join(out) + '\n')
print('wrote firmware.hex with %d words' % len(out))
