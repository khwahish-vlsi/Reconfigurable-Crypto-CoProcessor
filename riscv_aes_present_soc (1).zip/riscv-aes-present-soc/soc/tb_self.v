`timescale 1ns/1ps
// One built-in vector per mode; does NOT stop at the first done, so the full
// firmware (mkfw2.py / mkfw3.py) can finish. Usage: vsim -c work.tb_self -gMODE=<0|1>
module tb_self;
    parameter MODE = 0;     // 0 = AES-128, 1 = PRESENT-80

    reg clk = 0, resetn = 0;
    reg         mode_in;
    reg [127:0] key_in, pt_in, exp_in, act;
    reg         started, shown;

    always #5 clk = ~clk;

    soc_top dut (.clk(clk), .resetn(resetn),
                 .mode_in(mode_in), .key_in(key_in), .pt_in(pt_in));

    initial begin
        started = 0; shown = 0;
        mode_in = MODE;
        if (MODE == 0) begin
            key_in = 128'h2b7e151628aed2a6abf7158809cf4f3c;
            pt_in  = 128'h3243f6a8885a308d313198a2e0370734;
            exp_in = 128'h3925841d02dc09fbdc118597196a0b32;
        end else begin
            key_in = 128'h000000000000ffffffffffffffffffff;
            pt_in  = 128'h0;
            exp_in = 128'he72c46c0f5945049;
        end
        repeat (20) @(posedge clk);
        resetn = 1;
    end

    always @(posedge dut.s1) started = 1;

    always @(posedge dut.u_shared.done)
        if (resetn && started && !shown) begin
            shown = 1;
            @(posedge clk);
            act = dut.u_shared.ciphertext;
            $display("");
            $display("================ RESULT ================");
            if (!mode_in) begin
                $display(" MODE       : 0  (AES-128)");
                $display(" KEY        : %032h", key_in);
                $display(" PLAINTEXT  : %032h", pt_in);
                $display(" EXPECTED CT: %032h", exp_in);
                $display(" ACTUAL CT  : %032h", act);
                $display(" STATUS     : %s", (act == exp_in) ? "PASS" : "FAIL");
            end else begin
                $display(" MODE       : 1  (PRESENT-80)");
                $display(" KEY        : %020h", key_in[79:0]);
                $display(" PLAINTEXT  : %016h", pt_in[63:0]);
                $display(" EXPECTED CT: %016h", exp_in[63:0]);
                $display(" ACTUAL CT  : %016h", act[63:0]);
                $display(" STATUS     : %s", (act[63:0] == exp_in[63:0]) ? "PASS" : "FAIL");
            end
            $display("========================================");
            $display("");
        end

    initial begin #50_000_000; $display("TIMEOUT"); $finish; end
endmodule
