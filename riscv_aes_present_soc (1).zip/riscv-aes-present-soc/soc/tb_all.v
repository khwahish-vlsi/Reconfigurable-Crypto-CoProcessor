`timescale 1ns/1ps
// 2 AES + 2 PRESENT vectors. Usage: vsim -c work.tb_all +MODE=<0|1> +TEST=<0|1>   (then: run -all)
module tb_all;
    reg clk = 0, resetn = 0;
    reg         mode_in;
    reg [127:0] key_in, pt_in, exp_in, act;
    reg         started, shown;
    integer     MODE, TEST;

    always #5 clk = ~clk;

    soc_top dut (.clk(clk), .resetn(resetn),
                 .mode_in(mode_in), .key_in(key_in), .pt_in(pt_in));

    initial begin
        started = 0; shown = 0;
        if (!$value$plusargs("MODE=%d", MODE)) MODE = 0;
        if (!$value$plusargs("TEST=%d", TEST)) TEST = 0;
        mode_in = MODE[0];

        if (MODE == 0) begin
            case (TEST)
              0: begin key_in=128'h2b7e151628aed2a6abf7158809cf4f3c; pt_in=128'h3243f6a8885a308d313198a2e0370734; exp_in=128'h3925841d02dc09fbdc118597196a0b32; end
              default: begin key_in=128'h000102030405060708090a0b0c0d0e0f; pt_in=128'h00112233445566778899aabbccddeeff; exp_in=128'h69c4e0d86a7b0430d8cdb78070b4c55a; end
            endcase
        end else begin
            case (TEST)
              0: begin key_in=128'hffffffffffffffffffff; pt_in=128'h0; exp_in=128'he72c46c0f5945049; end
              default: begin key_in=128'ha1b2c3d4e5f6a7b8c9d0; pt_in=128'hfedcba9876543210; exp_in=128'ha8dc5293c96325f3; end
            endcase
        end
        repeat (20) @(posedge clk);
        resetn = 1;
    end

    always @(posedge dut.s1) started = 1;

    always @(posedge dut.u_shared.done)
        if (resetn && started && !shown) begin
            shown = 1;
            @(posedge clk);
            act = dut.u_shared.ciphertext;
            $display("");
            $display("[RESULT] MODE=%0d TEST=%0d", MODE, TEST);
            if (!mode_in) begin
                $display("  KEY      : %032h", key_in);
                $display("  PLAINTEXT: %032h", pt_in);
                $display("  EXPECTED : %032h", exp_in);
                $display("  ACTUAL   : %032h", act);
                $display("  STATUS   : %s", (act == exp_in) ? "PASS" : "FAIL");
            end else begin
                $display("  KEY      : %020h", key_in[79:0]);
                $display("  PLAINTEXT: %016h", pt_in[63:0]);
                $display("  EXPECTED : %016h", exp_in[63:0]);
                $display("  ACTUAL   : %016h", act[63:0]);
                $display("  STATUS   : %s", (act[63:0] == exp_in[63:0]) ? "PASS" : "FAIL");
            end
            $finish;
        end

    initial begin #50_000_000; $display("STATUS   : FAIL (TIMEOUT)"); $finish; end
endmodule
