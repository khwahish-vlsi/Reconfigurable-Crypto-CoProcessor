/* C version of the shared-core test (needs a RISC-V GCC; the mkfw*.py scripts do not).
   Shared core = slot 1 at 0x40001000. mode 0 = AES-128, mode 1 = PRESENT-80. */
#include <stdint.h>
#define SLOT(n) ((volatile uint32_t*)(0x40000000u + (n)*0x1000u))
#define CTRL 0
#define STATUS 1
#define KEY 4
#define PT 8
#define CT 12
#define PRINT(x)  (*(volatile uint32_t*)0x50000000 = (x))
#define FINISH()  (*(volatile uint32_t*)0x50000004 = 1)

static void test(int id, int slot, int mode,
                 const uint32_t *k, const uint32_t *p,
                 const uint32_t *exp, int first, int n)
{
    volatile uint32_t *b = SLOT(slot);
    PRINT(0xA0000000 + id);
    for (int i = 0; i < 4; i++) { b[KEY+i] = k[i]; b[PT+i] = p[i]; }
    b[CTRL] = 1 | (mode << 1);
    int t = 0;
    while (!(b[STATUS] & 2)) if (++t > 100000) { PRINT(0xBAD0BAD0); return; }
    int ok = 1;
    for (int i = 0; i < n; i++) {
        uint32_t c = b[CT + first + i];
        PRINT(c);
        if (c != exp[i]) ok = 0;
    }
    PRINT(ok ? 0x600D600D : 0xBAD0C0DE);
}

int main(void)
{
    /* AES-128, FIPS-197 Appendix B */
    const uint32_t ak[4] = {0x2b7e1516,0x28aed2a6,0xabf71588,0x09cf4f3c};
    const uint32_t ap[4] = {0x3243f6a8,0x885a308d,0x313198a2,0xe0370734};
    const uint32_t ae[4] = {0x3925841d,0x02dc09fb,0xdc118597,0x196a0b32};
    /* PRESENT-80: key in words 1..3, block in words 2..3 */
    const uint32_t pk0[4] = {0,0,0,0},  pp0[4] = {0,0,0,0};
    const uint32_t pk1[4] = {0,0x0000ffff,0xffffffff,0xffffffff};
    const uint32_t pe0[2] = {0x5579c138,0x7b228445};
    const uint32_t pe1[2] = {0xe72c46c0,0xf5945049};

    test(1, 1, 0, ak,  ap,  ae,  0, 4);   /* AES */
    test(2, 1, 1, pk0, pp0, pe0, 2, 2);   /* PRESENT, key = 0 */
    test(3, 1, 1, pk1, pp0, pe1, 2, 2);   /* PRESENT, key = all ones */
    test(4, 1, 0, ak,  ap,  ae,  0, 4);   /* back to AES (mode switching) */
    FINISH();
    while (1);
}
