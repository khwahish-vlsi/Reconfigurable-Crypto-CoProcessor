#!/bin/bash
# Run this ON THE SERVER, inside ~/capstone_git, to copy your RTL into this repo layout.
# Usage:  cd ~/capstone_git && bash <path-to>/collect_rtl.sh <repo-folder>
DEST=${1:-$HOME/riscv-aes-present-soc}
mkdir -p $DEST/{final_shared,final_unshared,aes_rtl,present_RTL}
cp final_shared/final_shared_{top,substitution,controller,datapath}.v $DEST/final_shared/
cp final_unshared/unshared_crypto.v $DEST/final_unshared/
cp aes_rtl/*.v $DEST/aes_rtl/
cp present/RTL/*.v $DEST/present_RTL/
find $DEST -type f | sort
