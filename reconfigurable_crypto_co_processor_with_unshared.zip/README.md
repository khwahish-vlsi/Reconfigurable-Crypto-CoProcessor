# Reconfigurable Cryptographic Co-Processor (AES-128 + PRESENT-80)

This repository contains a reconstructed Verilog reference implementation of AES-128 and PRESENT-80 encryption engines, a mode selector, and an explicitly named **unshared architecture**.

> **Important:** These files are reconstructed reference code, not a recovered copy of the user's original project. Verify them in your simulator and compare them against your project specification before submission.

## Architectures
- `crypto_unshared_top.v`: separate AES-128 and PRESENT-80 engine instances. `MODE=0` selects AES-128; `MODE=1` selects PRESENT-80. Both engines are instantiated independently, and a mux selects the output.
- `crypto_top.v`: earlier top-level selector with the same independent-core arrangement.

This package does **not** yet implement a genuinely shared-resource architecture unless your design's shared implementation is added separately. Do not describe the two as shared and unshared alternatives until the shared design is present and verified.

## File layout
```text
rtl/
  aes/aes128_encrypt.v
  present/present80_encrypt.v
  crypto_top.v
  crypto_unshared_top.v
testbench/
  aes128_tb.v
  present80_tb.v
  crypto_top_tb.v
  crypto_unshared_tb.v
docs/
  verification.md
```

## Known-answer test vectors
- PRESENT-80: all-zero 64-bit plaintext and all-zero 80-bit key -> `5579C1387B228445`
- AES-128: plaintext `00112233445566778899AABBCCDDEEFF`, key `000102030405060708090A0B0C0D0E0F` -> `69C4E0D86A7B0430D8CDB78070B4C55A`

## Simulate with Icarus Verilog
Run these from the repository root:
```sh
iverilog -g2012 -o unshared_test rtl/aes/aes128_encrypt.v rtl/present/present80_encrypt.v rtl/crypto_unshared_top.v testbench/crypto_unshared_tb.v
vvp unshared_test
```
The testbench is self-checking. Run it and inspect the output before reporting that the tests pass. Equivalent compilation can be performed in QuestaSim using the corresponding project/source setup.

## Design note
These encryption cores are combinational reference implementations for clarity and functional testing. They are not a timing-closed or physically verified ASIC/FPGA implementation. Synthesis quality, area, timing, and power depend on the target and tool flow.
