// Unshared architecture: AES-128 and PRESENT-80 are separate, independent
// encryption engines. MODE selects which engine's result is presented.
// MODE=0: AES-128; MODE=1: PRESENT-80.
// PRESENT uses plaintext[63:0] and key[79:0]; its result is zero-extended.
module crypto_unshared_top (
    input  wire         MODE,
    input  wire [127:0] plaintext,
    input  wire [127:0] key,
    output wire [127:0] ciphertext
);
    wire [127:0] aes_ciphertext;
    wire [63:0]  present_ciphertext;

    // Independent AES engine
    aes128_encrypt u_aes128 (
        .plaintext  (plaintext),
        .key        (key),
        .ciphertext (aes_ciphertext)
    );

    // Independent PRESENT-80 engine
    present80_encrypt u_present80 (
        .plaintext  (plaintext[63:0]),
        .key        (key[79:0]),
        .ciphertext (present_ciphertext)
    );

    // Output selection only; the two encryption engines are instantiated separately.
    assign ciphertext = (MODE == 1'b0)
                      ? aes_ciphertext
                      : {64'b0, present_ciphertext};
endmodule
