`timescale 1ns/1ps
module crypto_unshared_tb;
    reg MODE;
    reg [127:0] plaintext;
    reg [127:0] key;
    wire [127:0] ciphertext;

    crypto_unshared_top dut (
        .MODE(MODE),
        .plaintext(plaintext),
        .key(key),
        .ciphertext(ciphertext)
    );

    initial begin
        // Test AES-128 engine (MODE=0)
        MODE = 1'b0;
        plaintext = 128'h00112233445566778899AABBCCDDEEFF;
        key       = 128'h000102030405060708090A0B0C0D0E0F;
        #1;
        $display("Unshared AES ciphertext = %032h", ciphertext);
        if (ciphertext !== 128'h69C4E0D86A7B0430D8CDB78070B4C55A)
            $fatal(1, "UNSHARED AES TEST: FAIL");
        $display("UNSHARED AES TEST: PASS");

        // Test independent PRESENT-80 engine (MODE=1)
        MODE = 1'b1;
        plaintext = 128'h00000000000000000000000000000000;
        key       = 128'h00000000000000000000000000000000;
        #1;
        $display("Unshared PRESENT ciphertext = %032h", ciphertext);
        if (ciphertext !== 128'h00000000000000005579C1387B228445)
            $fatal(1, "UNSHARED PRESENT TEST: FAIL");
        $display("UNSHARED PRESENT TEST: PASS");

        $finish;
    end
endmodule
